<?php
/*
 * Sidebar File
 * Author & Copyright: VictorThemes
 * URL: https://victorthemes.com
 */

if (is_active_sidebar('main-widget')) {
	dynamic_sidebar('main-widget');
}