<?php
/*
 * The template for displaying the footer with no content.
 * Author & Copyright: VictorThemes
 * URL: https://victorthemes.com
 */
?>

	  </div>
	</div>
</div><!-- #elston-wrapper -->

<?php wp_footer(); ?>

</body>
</html><?php
